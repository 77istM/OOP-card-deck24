import java.util.ArrayList;	  	   	  	   		  	     	
import java.util.List;	  	   	  	   		  	     	
	  	   	  	   		  	     	
class Player {	  	   	  	   		  	     	
    private final String name;	  	   	  	   		  	     	
    private final List<Card> hand;	  	   	  	   		  	     	
	  	   	  	   		  	     	
    public Player(String name) {	  	   	  	   		  	     	
        this.name = name;	  	   	  	   		  	     	
        this.hand = new ArrayList<>();	  	   	  	   		  	     	
    }	  	   	  	   		  	     	
	  	   	  	   		  	     	
    public void addCardToHand(Card card) {	  	   	  	   		  	     	
        hand.add(card);	  	   	  	   		  	     	
    }	  	   	  	   		  	     	
	  	   	  	   		  	     	
    public List<Card> getHand() {	  	   	  	   		  	     	
        return hand;	  	   	  	   		  	     	
    }	  	   	  	   		  	     	
	  	   	  	   		  	     	
    public String getName() {	  	   	  	   		  	     	
        return name;	  	   	  	   		  	     	
    }	  	   	  	   		  	     	
	  	   	  	   		  	     	
    public int calculateScore() {	  	   	  	   		  	     	
        int score = 0;	  	   	  	   		  	     	
        int aceCount = 0;	  	   	  	   		  	     	
	  	   	  	   		  	     	
        for (Card card : hand) {	  	   	  	   		  	     	
            String value = card.getValue();	  	   	  	   		  	     	
            if (value.equals("Jack") || value.equals("Queen") || value.equals("King")) {	  	   	  	   		  	     	
                score += 10;	  	   	  	   		  	     	
            } else if (value.equals("Ace")) {	  	   	  	   		  	     	
                aceCount++;	  	   	  	   		  	     	
                score += 11; // Ace as 11	  	   	  	   		  	     	
            } else {	  	   	  	   		  	     	
                score += Integer.parseInt(value);	  	   	  	   		  	     	
            }	  	   	  	   		  	     	
        }	  	   	  	   		  	     	
	  	   	  	   		  	     	
        // Adjust score for Aces	  	   	  	   		  	     	
        while (score > 21 && aceCount > 0) {	  	   	  	   		  	     	
            score -= 10;	  	   	  	   		  	     	
            aceCount--;	  	   	  	   		  	     	
        }	  	   	  	   		  	     	
        return score;	  	   	  	   		  	     	
    }	  	   	  	   		  	     	
}