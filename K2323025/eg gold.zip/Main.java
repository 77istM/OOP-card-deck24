import java.util.ArrayList;	  	   	  	   		  	     	
import java.util.Random;	  	   	  	   		  	     	
import java.util.Scanner;	  	   	  	   		  	     	
import java.util.Collections;	  	   	  	   		  	     	
import java.util.List;	  	   	  	   		  	     	
	  	   	  	   		  	     	
public class Main	  	   	  	   		  	     	
{	  	   	  	   		  	     	
  public static void main(String[] args)	  	   	  	   		  	     	
  {	  	   	  	   		  	     	
    Scanner scanner = new Scanner(System. in );	  	   	  	   		  	     	
    System.out.print("player 1: ");	  	   	  	   		  	     	
    String player1Name = scanner.nextLine();	  	   	  	   		  	     	
    System.out.print("player 2: ");	  	   	  	   		  	     	
    String player2Name = scanner.nextLine();	  	   	  	   		  	     	
	  	   	  	   		  	     	
    Deck deck = new Deck();	  	   	  	   		  	     	
    Player player1 = new Player(player1Name);	  	   	  	   		  	     	
    Player player2 = new Player(player2Name);	  	   	  	   		  	     	
	  	   	  	   		  	     	
    // 1st  deal	  	   	  	   		  	     	
    player1.addCardToHand(deck.drawCard());	  	   	  	   		  	     	
    player2.addCardToHand(deck.drawCard());	  	   	  	   		  	     	
	  	   	  	   		  	     	
    // P1 turn	  	   	  	   		  	     	
    takeTurn(player1, deck, scanner);	  	   	  	   		  	     	
	  	   	  	   		  	     	
    // P2 turn	  	   	  	   		  	     	
    takeTurn(player2, deck, scanner);	  	   	  	   		  	     	
	  	   	  	   		  	     	
    // winner	  	   	  	   		  	     	
    int player1Score = player1.calculateScore();	  	   	  	   		  	     	
    int player2Score = player2.calculateScore();	  	   	  	   		  	     	
	  	   	  	   		  	     	
    System.out.println(player1.getName() + "'s score: " + player1Score);	  	   	  	   		  	     	
    System.out.println(player2.getName() + "'s score: " + player2Score);	  	   	  	   		  	     	
	  	   	  	   		  	     	
    if (player1Score > 21 && player2Score > 21)	  	   	  	   		  	     	
    {	  	   	  	   		  	     	
      System.out.println("Both players busted! It's a tie.");	  	   	  	   		  	     	
    }	  	   	  	   		  	     	
    else if (player1Score > 21)	  	   	  	   		  	     	
    {	  	   	  	   		  	     	
      System.out.println(player1.getName() + " busted! " + player2.getName() + " wins!");	  	   	  	   		  	     	
    }	  	   	  	   		  	     	
    else if (player2Score > 21)	  	   	  	   		  	     	
    {	  	   	  	   		  	     	
      System.out.println(player2.getName() + " busted! " + player1.getName() + " wins!");	  	   	  	   		  	     	
    }	  	   	  	   		  	     	
    else	  	   	  	   		  	     	
    {	  	   	  	   		  	     	
      if (player1Score > player2Score)	  	   	  	   		  	     	
      {	  	   	  	   		  	     	
        System.out.println(player1.getName() + " wins!");	  	   	  	   		  	     	
      }	  	   	  	   		  	     	
      else if (player2Score > player1Score)	  	   	  	   		  	     	
      {	  	   	  	   		  	     	
        System.out.println(player2.getName() + " wins!");	  	   	  	   		  	     	
      }	  	   	  	   		  	     	
      else	  	   	  	   		  	     	
      {	  	   	  	   		  	     	
        System.out.println("It's a tie!");	  	   	  	   		  	     	
      }	  	   	  	   		  	     	
    }	  	   	  	   		  	     	
	  	   	  	   		  	     	
    scanner.close();	  	   	  	   		  	     	
  }	  	   	  	   		  	     	
	  	   	  	   		  	     	
  private static void takeTurn(Player player, Deck deck, Scanner scanner)	  	   	  	   		  	     	
  {	  	   	  	   		  	     	
    while (true)	  	   	  	   		  	     	
    {	  	   	  	   		  	     	
      System.out.println(player.getName() + "'s turn. Current hand:");	  	   	  	   		  	     	
      List < Card > hand = player.getHand();	  	   	  	   		  	     	
      for (Card card: hand)	  	   	  	   		  	     	
      {	  	   	  	   		  	     	
        System.out.println(card.getValue() + " of " + card.getSuit());	  	   	  	   		  	     	
      }	  	   	  	   		  	     	
      int score = player.calculateScore();	  	   	  	   		  	     	
      System.out.println("Total score: " + score);	  	   	  	   		  	     	
      if (score >= 21)	  	   	  	   		  	     	
      {	  	   	  	   		  	     	
        System.out.println(player.getName() + " reached 21 or busted.");	  	   	  	   		  	     	
        break;	  	   	  	   		  	     	
      }	  	   	  	   		  	     	
      System.out.print("Do you want to stick (s) or twist (t)? ");	  	   	  	   		  	     	
      String choice = scanner.nextLine().toLowerCase();	  	   	  	   		  	     	
      if (choice.equals("s"))	  	   	  	   		  	     	
      {	  	   	  	   		  	     	
        System.out.println(player.getName() + " decided to stick.");	  	   	  	   		  	     	
        break;	  	   	  	   		  	     	
      }	  	   	  	   		  	     	
      else if (choice.equals("t"))	  	   	  	   		  	     	
      {	  	   	  	   		  	     	
        Card drawnCard = deck.drawCard();	  	   	  	   		  	     	
        System.out.println("You drew: " + drawnCard.getValue() + " of " + drawnCard.getSuit());	  	   	  	   		  	     	
        player.addCardToHand(drawnCard);	  	   	  	   		  	     	
      }	  	   	  	   		  	     	
      else	  	   	  	   		  	     	
      {	  	   	  	   		  	     	
        System.out.println("Invalid choice. Please enter 's' to stick or 't' to twist.");	  	   	  	   		  	     	
      }	  	   	  	   		  	     	
    }	  	   	  	   		  	     	
  }	  	   	  	   		  	     	
}