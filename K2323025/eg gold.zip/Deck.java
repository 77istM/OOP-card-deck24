import java.util.ArrayList;	  	   	  	   		  	     	
import java.util.Random;	  	   	  	   		  	     	
import java.util.Collections;	  	   	  	   		  	     	
import java.util.List;	  	   	  	   		  	     	
class Deck	  	   	  	   		  	     	
{	  	   	  	   		  	     	
  private final List < Card > cards;	  	   	  	   		  	     	
	  	   	  	   		  	     	
  public Deck()	  	   	  	   		  	     	
  {	  	   	  	   		  	     	
    cards = new ArrayList < > ();	  	   	  	   		  	     	
    String[] suits = {	  	   	  	   		  	     	
      "Clubs", "Spades", "Hearts", "Diamonds"	  	   	  	   		  	     	
    };	  	   	  	   		  	     	
    String[] values = {	  	   	  	   		  	     	
      "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"	  	   	  	   		  	     	
    };	  	   	  	   		  	     	
	  	   	  	   		  	     	
    for (String suit: suits)	  	   	  	   		  	     	
    {	  	   	  	   		  	     	
      for (String value: values)	  	   	  	   		  	     	
      {	  	   	  	   		  	     	
        cards.add(new Card(suit, value));	  	   	  	   		  	     	
      }	  	   	  	   		  	     	
    }	  	   	  	   		  	     	
    shuffle();	  	   	  	   		  	     	
  }	  	   	  	   		  	     	
	  	   	  	   		  	     	
  public void shuffle()	  	   	  	   		  	     	
  {	  	   	  	   		  	     	
    Collections.shuffle(cards);	  	   	  	   		  	     	
  }	  	   	  	   		  	     	
	  	   	  	   		  	     	
  public Card drawCard()	  	   	  	   		  	     	
  {	  	   	  	   		  	     	
    return cards.remove(0);	  	   	  	   		  	     	
  }	  	   	  	   		  	     	
}