import java.util.ArrayList;	  	   	  	   		  	     	
import java.util.Random;	  	   	  	   		  	     	
import java.util.Scanner;	  	   	  	   		  	     	
	  	   	  	   		  	     	
public class Main	  	   	  	   		  	     	
{	  	   	  	   		  	     	
  public static void main(String[] args)	  	   	  	   		  	     	
  {	  	   	  	   		  	     	
    Deck a = new Deck();	  	   	  	   		  	     	
    Random rand = new Random();	  	   	  	   		  	     	
    Scanner scanner = new Scanner(System. in );	  	   	  	   		  	     	
    int score = 0;	  	   	  	   		  	     	
	  	   	  	   		  	     	
    while (true)	  	   	  	   		  	     	
    {	  	   	  	   		  	     	
      int randomIndex = rand.nextInt(a.getCards().size());	  	   	  	   		  	     	
      Card card = a.getCards().get(randomIndex);	  	   	  	   		  	     	
      a.getCards().remove(randomIndex);	  	   	  	   		  	     	
	  	   	  	   		  	     	
      System.out.println("The card is " + card.getSuits() + " " + card.getValues());	  	   	  	   		  	     	
      System.out.println("The next card will be higher or lower? Enter 'higher' or 'lower':");	  	   	  	   		  	     	
      String guess = scanner.nextLine();	  	   	  	   		  	     	
	  	   	  	   		  	     	
      randomIndex = rand.nextInt(a.getCards().size());	  	   	  	   		  	     	
      Card nextCard = a.getCards().get(randomIndex);	  	   	  	   		  	     	
      a.getCards().remove(randomIndex);	  	   	  	   		  	     	
	  	   	  	   		  	     	
      System.out.println("The next card is " + nextCard.getSuits() + " " + nextCard.getValues());	  	   	  	   		  	     	
	  	   	  	   		  	     	
      if ((guess.equals("higher") && nextCard.getValues().compareTo(card.getValues()) > 0) || (guess.equals("lower") && nextCard.getValues().compareTo(card.getValues()) < 0))	  	   	  	   		  	     	
      {	  	   	  	   		  	     	
        score++;	  	   	  	   		  	     	
        System.out.println("You guessed right! Your score is now " + score + ".");	  	   	  	   		  	     	
      }	  	   	  	   		  	     	
      else	  	   	  	   		  	     	
      {	  	   	  	   		  	     	
        System.out.println("You guessed wrong. Your final score is " + score + ".");	  	   	  	   		  	     	
        break;	  	   	  	   		  	     	
      }	  	   	  	   		  	     	
    }	  	   	  	   		  	     	
	  	   	  	   		  	     	
    scanner.close();	  	   	  	   		  	     	
  }	  	   	  	   		  	     	
}