import java.util.ArrayList;	  	   	  	   		  	     	
import java.util.Random;	  	   	  	   		  	     	
	  	   	  	   		  	     	
public class Card {	  	   	  	   		  	     	
    private String suits;	  	   	  	   		  	     	
    private String values;	  	   	  	   		  	     	
	  	   	  	   		  	     	
    public void setSuits(String suits) {	  	   	  	   		  	     	
        this.suits = suits;	  	   	  	   		  	     	
    }	  	   	  	   		  	     	
	  	   	  	   		  	     	
    public String getSuits() {	  	   	  	   		  	     	
        return this.suits;	  	   	  	   		  	     	
    }	  	   	  	   		  	     	
	  	   	  	   		  	     	
    public void setValues(String values) {	  	   	  	   		  	     	
        this.values = values;	  	   	  	   		  	     	
    }	  	   	  	   		  	     	
	  	   	  	   		  	     	
    public String getValues() {	  	   	  	   		  	     	
        return this.values;	  	   	  	   		  	     	
    }	  	   	  	   		  	     	
}