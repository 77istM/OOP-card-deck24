import java.util.ArrayList;	  	   	  	   		  	     	
import java.util.Random;	  	   	  	   		  	     	
	  	   	  	   		  	     	
public class Deck {	  	   	  	   		  	     	
    private ArrayList<Card> cards = new ArrayList<>();	  	   	  	   		  	     	
	  	   	  	   		  	     	
    public void setCards(ArrayList<Card> cards) {	  	   	  	   		  	     	
        this.cards = cards;	  	   	  	   		  	     	
    }	  	   	  	   		  	     	
	  	   	  	   		  	     	
    public ArrayList<Card> getCards() {	  	   	  	   		  	     	
        return this.cards;	  	   	  	   		  	     	
    }	  	   	  	   		  	     	
	  	   	  	   		  	     	
    String[] suits = {	  	   	  	   		  	     	
        "clubs", "spades", "hearts", "diamonds"	  	   	  	   		  	     	
    };	  	   	  	   		  	     	
	  	   	  	   		  	     	
    String[] values = {	  	   	  	   		  	     	
        "ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "jack", "queen", "king"	  	   	  	   		  	     	
    };	  	   	  	   		  	     	
	  	   	  	   		  	     	
    public Deck() {	  	   	  	   		  	     	
        for (int i = 0; i < suits.length; i++) {	  	   	  	   		  	     	
            for (int j = 0; j < values.length; j++) {	  	   	  	   		  	     	
                Card allcard = new Card();	  	   	  	   		  	     	
                allcard.setSuits(suits[i]);	  	   	  	   		  	     	
                allcard.setValues(values[j]);	  	   	  	   		  	     	
                this.cards.add(allcard);	  	   	  	   		  	     	
            }	  	   	  	   		  	     	
        }	  	   	  	   		  	     	
    }	  	   	  	   		  	     	
}