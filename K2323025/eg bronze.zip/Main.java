import java.util.ArrayList;	  	   	  	   		  	     	
import java.util.Random;	  	   	  	   		  	     	
	  	   	  	   		  	     	
public class Main {	  	   	  	   		  	     	
    public static void main(String[] args) {	  	   	  	   		  	     	
        Deck a = new Deck();	  	   	  	   		  	     	
        Random rand = new Random();	  	   	  	   		  	     	
        ArrayList<Card> hand = new ArrayList<>();	  	   	  	   		  	     	
        for (int i = 0; i < 5; i++) {	  	   	  	   		  	     	
            int randomIndex = rand.nextInt(a.getCards().size());	  	   	  	   		  	     	
            hand.add(a.getCards().get(randomIndex));	  	   	  	   		  	     	
            a.getCards().remove(randomIndex);	  	   	  	   		  	     	
        }	  	   	  	   		  	     	
        for (Card card : hand) {	  	   	  	   		  	     	
            System.out.println(card.getSuits() + " " + card.getValues());	  	   	  	   		  	     	
        }	  	   	  	   		  	     	
    }	  	   	  	   		  	     	
}